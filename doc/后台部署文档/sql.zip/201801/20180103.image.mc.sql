ALTER TABLE hmserver.t_image ADD machineCode VARCHAR(20) NULL;
CREATE INDEX idx_image_machineCode ON hmserver.t_image (machineCode);