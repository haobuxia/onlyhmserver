ALTER TABLE hmserver.t_gpsgyro MODIFY downAcceleration LONG;
ALTER TABLE hmserver.t_gpsgyro MODIFY upAcceleration LONG;