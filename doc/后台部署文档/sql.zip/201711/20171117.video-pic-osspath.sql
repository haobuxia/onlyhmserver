ALTER TABLE hmserver.t_netease_msg MODIFY fullMsg TEXT; --已直接执行

ALTER TABLE hmserver.t_video ADD picOssPath VARCHAR(100) NULL;