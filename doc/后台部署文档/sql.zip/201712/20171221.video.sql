ALTER TABLE hmserver.t_video ADD hasGpsData TINYINT(1) NULL;
ALTER TABLE hmserver.t_video ADD trackVideoOssPath VARCHAR(100) NULL;
