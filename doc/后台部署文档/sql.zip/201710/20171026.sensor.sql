ALTER TABLE hmserver.t_sensor MODIFY lat FLOAT(12,6);
ALTER TABLE hmserver.t_sensor MODIFY lon FLOAT(12,6);
ALTER TABLE hmserver.t_sensor MODIFY xa FLOAT(12,6);
ALTER TABLE hmserver.t_sensor MODIFY ya FLOAT(12,6);
ALTER TABLE hmserver.t_sensor MODIFY za FLOAT(12,6);
ALTER TABLE hmserver.t_sensor MODIFY xg FLOAT(12,6);
ALTER TABLE hmserver.t_sensor MODIFY yg FLOAT(12,6);
ALTER TABLE hmserver.t_sensor MODIFY zg FLOAT(12,6);

